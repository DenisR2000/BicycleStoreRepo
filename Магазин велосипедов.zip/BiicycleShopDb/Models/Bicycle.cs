﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiicycleShopDb.Models
{
    public class Bicycle
    {
        public int BicycleId { get; set; }
        public string Title { get; set; }
        public string Class { get; set; }
        public int Wheel_Diameter { get; set; }
        public string Clolor { get; set; }
        public int Number_Speeds { get; set; }
        public string Frame { get; set; }
        public string Frame_Material { get; set; }
        public string Img_Url { get; set; }
        public int Prise { get; set; }
    }
}
