﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BiicycleShopDb.Models;
using Microsoft.EntityFrameworkCore;
using ReflectionIT.Mvc.Paging;

namespace BiicycleShopDb.Controllers
{
    public class AdminController : Controller
    {
        BicycleContext context;
        public AdminController(BicycleContext context)
        {
            this.context = context;
        }

        public async Task< IActionResult> Index(int page = 1)
        {
            var query = context.Bicycle.AsNoTracking().OrderBy(p => p.Prise);
            var model = await PagingList.CreateAsync(query, 6, page);
            return View(model);
        }
        public IActionResult Create(int? id)
        {
            var bicycleToEdit = context.Bicycle.Find(id);
            return View(bicycleToEdit);
        }
        [HttpPost]
        public IActionResult Create(Bicycle bicycle)
        {
            if(bicycle.BicycleId == 0)
            {
                context.Bicycle.Add(bicycle);
            }
            else
            {
                var bicycleToEdit = context.Bicycle.FirstOrDefault(x => x.BicycleId == x.BicycleId);
                bicycleToEdit.Title = bicycle.Title;
                bicycleToEdit.Class = bicycle.Class;
                bicycleToEdit.Clolor = bicycle.Clolor;
                bicycleToEdit.Frame = bicycle.Frame;
                bicycleToEdit.Frame_Material = bicycle.Frame_Material;
                bicycleToEdit.Number_Speeds = bicycle.Number_Speeds;
                bicycleToEdit.Prise = bicycle.Prise;
                bicycleToEdit.Wheel_Diameter = bicycle.Wheel_Diameter;
                bicycleToEdit.Img_Url = bicycle.Img_Url;
            }
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpPost]
        public IActionResult Remove(int BicycleId)
        {
            context.Bicycle.Remove(context.Bicycle.Find(BicycleId));
            context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
