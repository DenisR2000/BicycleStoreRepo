﻿using BiicycleShopDb.Models;
using BiicycleShopDb.Serises;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using ReflectionIT.Mvc.Paging;
using System;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace BiicycleShopDb.Controllers
{
    public class HomeController : Controller
    {
        BicycleContext context;
        public HomeController(BicycleContext context)
        {
            this.context = context;
        }
        
        public async Task<IActionResult> Index(int page = 1)
        {
            var query = context.Bicycle.AsNoTracking().OrderBy(p => p.Prise);
            var model = await PagingList.CreateAsync(query, 6, page);
            return View(model);
        }

        [HttpPost]
        public IActionResult Index(Order order)
        {

            return View(context.Bicycle.ToList());
        }

        public IActionResult Buy(int? id)
        {
            if(id == null)
            {
                return RedirectToAction("Index");
            }
            ViewBag.BicycleId = id;
            return View();
        }

        [HttpPost]
        public  IActionResult Buy(Order order)
        {
            try
            {
                string message = "";
                string message_mail = "";

                context.Order.Add(order);
                context.SaveChanges();
                message = $"Спасибо { order.Name} за заказ!";
                message_mail = $"Спасибо {order.Name} за заказ велосипеда!\nВаш номер заказа {order.OrderId}\nСпасибо что выбрали нас!";

                ServisMail.SendMessage(message_mail, order.Email);
                ViewBag.Message = message;

            }
            catch(Exception ex)
            { }
            return View();
        }

    }
}
